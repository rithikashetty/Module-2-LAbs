package com.cg.eis.exception;

public class SalaryException extends Exception {

	int id;
	String name;
	double salary;
	String designation;
	
public  SalaryException(String msg){
		
		super(msg);
		
	}
	
}

