package com.cg.eis.pl;

import com.cg.eis.exception.SalaryException;
import com.cg.eis.service.EmployeeServiceImpl;
import com.cg.eis.service.IEmploymentService;

public class EmployeeMain {
	
	public static void main(String[] args) throws SalaryException{
	
	 IEmploymentService empservice = new EmployeeServiceImpl();
	 empservice.inputEmployee();
	  empservice.findInsuranceScheme();
	  empservice.displayDetails();

}
}
