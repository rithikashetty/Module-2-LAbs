package com.cg.eis.service;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.SalaryException;

public class EmployeeServiceImpl implements IEmploymentService{

	 int id;
	 String name;
	 double salary;
	 String designation;
	 String insuranceScheme = null;
	 Employee e;
	 
	public void inputEmployee(){
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Enter id of Employee");
	id=sc.nextInt();
	
	System.out.println("Enter name of Employee");
	name=sc.next();	
	
	System.out.println("Enter salary of Employee");
	salary=sc.nextDouble();
	
	System.out.println("Enter Designation ");
	designation=sc.next();
	
	try {
		e = new Employee(id,name,salary,designation);
	} catch (SalaryException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}


	public void findInsuranceScheme() {
		
		double salary=e.getSalary();
		String designation = e.getDesignation();
		
		if(((salary>5000)&&(salary<2000))&&(designation.equals("System Associate"))){
			
			
			 insuranceScheme = "Scheme C";
			
		}
		else if(((salary>=20000)&&(salary<40000))&&(designation.equals("Programmer")))
		{
			
			 insuranceScheme = "Scheme B";
			
		}
		
		
		else if((salary>=40000)&&(designation.equals("Manager"))){
			
			insuranceScheme = "Scheme A";
			
		}
		
		else if((salary<5000)&&(designation.equals("Clerk"))){
			
			insuranceScheme = "No Scheme";
			
		}
		
		e.setInsuranceScheme(insuranceScheme);
		
	}


	public void displayDetails() {
		e.display();
		
	}
	
}
