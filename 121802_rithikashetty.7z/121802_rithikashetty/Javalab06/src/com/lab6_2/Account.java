package com.lab6_2;

public class Account {
	
	private long accNum;//if acnt no is static then same acnt no will be assigned to everyone
	private double balance;
	private Person accnHolder;
	static int count=10000;
	
	public Account(){
		
		super();
		count++;
		accNum=count;
		
	}
	
	public Account(double balance) {
		super();
		count++;
		this.accNum = count;
		this.balance = balance;
	}
	
	public long getAccNum() {
		return accNum;
	}
	
	public Person getAccnHolder() {
		return accnHolder;
	}
	
	public double getBalance(){
		return balance;
				
	}
	
	
	public void setAccnHolder(Person accnHolder) {
		this.accnHolder = accnHolder;
	}
	
	public void deposit(double amount){
		
		balance=balance+amount;
		
	}
	

	public void withdraw(double amt) {
		balance=balance-amt;
		
	} 
	
	public String toString() {
	return "Account [accNum=" + accNum + ", balance=" + balance
			+ ", accnHolder=" + accnHolder + "]";
}

}


