package com.lab6_2;

public class SavingAccount extends Account {

	final public int minimumBalance=500;
	
	public SavingAccount(double balance){
		
		super(balance);
	}
	
	public void withdraw(double amt){
		double bal = getBalance();
		
		if((amt-bal)>=minimumBalance){
			
			super.withdraw(amt);
		}
		
		else{
			
			System.out.println("Balance Should be minimum of Rs.500");
		}
		
	}
}
