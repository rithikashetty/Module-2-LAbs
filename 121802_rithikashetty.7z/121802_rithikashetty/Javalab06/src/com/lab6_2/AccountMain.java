package com.lab6_2;

public class AccountMain {

	public static void main(String[] args) throws AgeException {
		
		Person smith =  new Person("smith",23);
		Person kathy = new Person("kathy",25);
		
		Account accountsmith = new SavingAccount(8000);
		accountsmith.setAccnHolder(smith);
		System.out.println(accountsmith);
		
		Account kathyAccount = new CurrentAccount(3000);
		kathyAccount.setAccnHolder(kathy);
		System.out.println(kathyAccount);
		
		accountsmith.withdraw(7000);
		kathyAccount.withdraw(5000);
		System.out.println("updated balance of smith is:"+accountsmith.getBalance());
		System.out.println("updated balance of smith is:"+kathyAccount.getBalance());

	}

}

