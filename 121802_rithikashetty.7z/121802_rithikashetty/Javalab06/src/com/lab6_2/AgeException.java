package com.lab6_2;

public class AgeException extends Exception {

	String name;
	float age;
	
	public  AgeException(String msg){
		
		super(msg);
		
	}
}

