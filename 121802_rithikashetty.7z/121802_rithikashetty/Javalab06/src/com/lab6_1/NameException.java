package com.lab6_1;

public class NameException extends Exception {
	
	public NameException(String msgs){
	super(msgs);
	}

}
