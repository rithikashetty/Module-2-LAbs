package com.lab6_1;

public class PersonMain2 {

	public static void main(String[] args) throws NameException {
		
		System.out.println("Person Details");
		System.out.println("----------------------------------");
		
		Person2 person21;
		person21 = new Person2("Rithika","Shetty",'F');
		System.out.println("First Name: "+person21.getFirstname());
		System.out.println("Last Name: "+person21.getLastname());
		System.out.println("Gender: "+person21.getGender());
		
		System.out.println("Person Details");
		System.out.println("----------------------------------");
		
		Person2 person22= new Person2("Prithvi","Shetty",'M');
		System.out.println("First Name: "+person22.getFirstname());
		System.out.println("Last Name: "+person22.getLastname());
		System.out.println("Gender: "+person22.getGender());

		Person2 person23= new Person2("","Shetty",'M');
		System.out.println("First Name: "+person23.getFirstname());
		System.out.println("Last Name: "+person23.getLastname());
		System.out.println("Gender: "+person23.getGender());
		
		
		
	}

}
