package com.lab5_3;

public class SavingsAcc extends Account {

	
	private double minBalance=1000;
	private long accNum;
	private double balance;
	
	

	public SavingsAcc(double balance) {
		super(balance);
		this.balance= balance;
	}


	@Override
	public void withdraw(double amt){
		if(balance-amt>=minBalance){
		balance= balance-amt;
		}
		else{
			System.out.println("Insufficient balance ");
		}
		
	}
	
	@Override
	public double getBalance()
	{
		return balance;
	}
	
	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance
				+ ", accHolder=" + accHolder + "]";
	}
}
