package com.lab5_3;

public abstract class Account {
	
	protected long accNum;
	protected double balance;
	
	protected Person accHolder;
	static int count=1001;
	
	public void deposit(double amt){
		balance= balance+amt;
		
	}
	
	public abstract void withdraw(double amt);
	
		
	
	
	public abstract double getBalance();
	
	
	

	public long getAccNum() {
		return accNum;
	}

	/*public void setAccNum(long accNum) {
		this.accNum = accNum;
	}*/

	public Person getAccHolder() {
		return accHolder;
	}

	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}

	

/*	public void setBalance(double balance) {
		this.balance = balance;
	}*/
	
	
	public Account(double balance) {
		super();
		count++;
		this.accNum = count;
		this.balance = balance;
	}

public Account() {
	super();
	count++;
}
/*
@Override
public String toString() {
	return "Account [accNum=" + accNum + ", balance=" + balance
			+ ", accHolder=" + accHolder + "]";
}*/

}
