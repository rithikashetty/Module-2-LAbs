package com.lab5_3;

import java.util.Scanner;


public class Accountmain {

	public static void main(String[] args) {

		Scanner sc= new Scanner(System.in);
		
		Person smith= new Person("Smith", 23);
		Person kathy= new Person("Kathy", 24);
		Person leila= new Person("Leila", 24);
		Person raj= new Person("Raj", 26);
		
		Account smithAcnt= new SavingsAcc(2000);
		smithAcnt.setAccHolder(smith);
		
		Account kathyAcnt= new CurrentAcc(3000);
		kathyAcnt.setAccHolder(kathy);
		
		Account leilaAcnt= new SavingsAcc(3000);
		leilaAcnt.setAccHolder(leila);
		
		Account rajAcnt= new CurrentAcc(7000);
		rajAcnt.setAccHolder(raj);
		
		System.out.println("Enter deposit amt for Smith :");
		double s_dp= sc.nextDouble();
		smithAcnt.deposit(s_dp);
		
		System.out.println("Enter withdraw amt for Kathy :");
		double k_wd= sc.nextDouble();
		kathyAcnt.withdraw(k_wd);
		
		System.out.println("Enter deposit amt for Leila :");
		double l_dp= sc.nextDouble();
		leilaAcnt.deposit(l_dp);
		
		System.out.println("Updated balance for Smith:"+smithAcnt.getBalance());
		System.out.println("Updated balance for Kathy:"+kathyAcnt.getBalance());
		System.out.println("Updated balance for Leila:"+leilaAcnt.getBalance());
		
		System.out.println();

		
		System.out.println(smithAcnt);
		System.out.println(kathyAcnt);
		System.out.println(leilaAcnt);
		System.out.println(rajAcnt);
		
		System.out.println("Enter withdraw amt for Leila :");
		double l_wd= sc.nextDouble();
		leilaAcnt.withdraw(l_wd);
		System.out.println("Updated balance for Leila:"+leilaAcnt.getBalance());

		System.out.println("Enter withdraw amt for Raj :");
		double r_wd= sc.nextDouble();
		rajAcnt.withdraw(r_wd);
		System.out.println();
		
		System.out.println(smithAcnt);
		System.out.println(kathyAcnt);
		System.out.println(leilaAcnt);
		System.out.println(rajAcnt);
		
		
	}


}
