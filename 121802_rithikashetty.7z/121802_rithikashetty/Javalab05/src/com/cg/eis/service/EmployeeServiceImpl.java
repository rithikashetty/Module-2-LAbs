package com.cg.eis.service;

public class EmployeeServiceImpl implements IEmployeeService{
/*	Employee e;
	public void inputEmployee(){
	 System.out.println("Enter id of Employee");
	  id=sc.nextInt();
	System.out.println("Enter name of Employee");
	name=sc.next();
	
	e = new Employee(id,name,salary,designation);
		}*/

	public String findInsuranceSchema(Double salary, String designation){ //dont pass the parameters
		
		String insuranceScheme = null;
		
		//int salary=e.getsalary();
		//String designation = e.getdesignation
		
		if(((salary>5000)&&(salary<2000))&&(designation.equals("System Associate"))){
			
			
			 insuranceScheme = "Scheme C";
			
		}
		else if(((salary>=20000)&&(salary<40000))&&(designation.equals("Programmer")))
		{
			
			 insuranceScheme = "Scheme B";
			
		}
		
		
		else if((salary>=40000)&&(designation.equals("Manager"))){
			
			insuranceScheme = "Scheme A";
			
		}
		
		else if((salary<5000)&&(designation.equals("Clerk"))){
			
			insuranceScheme = "No Scheme";
			
		}
		
	
		return insuranceScheme;
		//e.setInsuranceScheme(insuranceScheme);
		//System.out.println(insuranceScheme);
		
	}
	
	

}
