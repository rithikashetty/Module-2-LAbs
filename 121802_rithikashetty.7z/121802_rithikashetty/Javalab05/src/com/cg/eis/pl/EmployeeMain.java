package com.cg.eis.pl;

import java.util.Scanner;



import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeServiceImpl;

public class EmployeeMain {

	public static void main(String[] args) {
		 int id;
		 String name;
		 double salary;
		 String designation;
		 String insuranceScheme = null;
		  
		 Scanner sc = new Scanner(System.in);
		 
		 System.out.println("Enter id of Employee");
		  id=sc.nextInt();

		  
		System.out.println("Enter name of Employee");
		name=sc.next();
		//emp.setName(name);
		
		
		System.out.println("Enter salary of Employee");
		salary=sc.nextDouble();
		//emp.setSalary(salary);
	
		
		System.out.println("Enter Designation ");
		designation=sc.next();
		//emp.setDesignation(designation);
		
		  
		  Employee emp = new Employee();
		  emp.setId(id);
		  emp.setName(name);
		  emp.setSalary(salary);
		  emp.setDesignation(designation);
		  
		  EmployeeServiceImpl empservice = new EmployeeServiceImpl();
		  insuranceScheme=empservice.findInsuranceSchema(salary,designation);
		  emp.setInsuranceScheme(insuranceScheme);
		  
		  emp.display();
		
		
	}

}


