package com.cg.ma.service;

import java.util.List;

import com.cg.ma.dto.Mobile;
import com.cg.ma.exception.MobileException;
import com.cg.ma.exception.PurchaseDetailsException;

public interface IMobileService {

	List<Mobile> showAll() throws MobileException;
	boolean deleteMobile(int mobileid) throws MobileException;
	List<Mobile>searchByRange(int start,int end) throws MobileException;
	List<Mobile> showAllMobiles() throws MobileException;
	boolean Mobileid(int mid) throws MobileException;
	boolean updateQty(int mid, int qty) throws MobileException;
	boolean insertPurchaseDetails(String cust_name,String cust_mail,String cust_phone,int mid) throws PurchaseDetailsException;

}
