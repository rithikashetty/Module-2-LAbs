/*package com.cg.ma.service;

import com.cg.ma.exception.PurchaseDetailsException;

public interface IPurchaseDetailsService {
	
	boolean insertPurchaseDetails(String cust_name,String cust_mail,String cust_phone,int mid) throws PurchaseDetailsException;
}*/