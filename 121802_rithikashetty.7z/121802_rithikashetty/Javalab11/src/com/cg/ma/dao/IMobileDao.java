package com.cg.ma.dao;

import java.util.List;

import com.cg.ma.dto.Mobile;
import com.cg.ma.exception.MobileException;
import com.cg.ma.exception.PurchaseDetailsException;

public interface IMobileDao {
	
	List<Mobile> showAll() throws MobileException;
	boolean deleteMobile(int mobileid) throws MobileException;
	List<Mobile>searchByRange(int start,int end) throws MobileException;
	boolean updateQty(int mobileid,int qty)throws MobileException;
	boolean Mobileid(int mid)throws MobileException;
	boolean insertPurchaseDetails(String cust_name,String cust_mail,String cust_phone,int mobileid) throws PurchaseDetailsException;
}
