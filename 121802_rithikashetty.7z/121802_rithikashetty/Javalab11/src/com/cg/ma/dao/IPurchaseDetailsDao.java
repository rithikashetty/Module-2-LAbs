/*package com.cg.ma.dao;

import com.cg.ma.exception.PurchaseDetailsException;

public interface IPurchaseDetailsDao  {
	
	boolean insertPurchaseDetails(String cust_name,String cust_mail,String cust_phone,int mobileid) throws PurchaseDetailsException;

}
*/