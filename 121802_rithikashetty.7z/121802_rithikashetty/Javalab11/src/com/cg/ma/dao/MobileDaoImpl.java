package com.cg.ma.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.ma.dto.Mobile;
import com.cg.ma.dto.PurchaseDetails;
import com.cg.ma.exception.MobileException;
import com.cg.ma.exception.PurchaseDetailsException;
import com.cg.ma.util.JdbcUtil;

public class MobileDaoImpl implements IMobileDao {

	Connection conn;
	PreparedStatement pst;
	private static final Logger mylogger=Logger.getLogger(JdbcUtil.class);
	
	@Override
	public List<Mobile> showAll() {
		
		try {
			conn=JdbcUtil.getConnection();
		} catch (MobileException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		String query="SELECT * from mobiles";
		
		List<Mobile>mList=new ArrayList<Mobile>();
		
		try {
			pst = conn.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				
				int m_id=rs.getInt(1); //either pass index(always starts with 1) or columnname in double quotes
				String m_names = rs.getString(2);
				double m_prices=rs.getInt(3);
				int m_qty=rs.getInt(4);
				Mobile m = new Mobile();
				m.setMobileid(m_id);
				m.setMobilename(m_names);
				m.setQuantity(m_qty);
				m.setPrice(m_prices);
				
				mList.add(m);
				
				mylogger.info("All Data is displayed");
			}
			
		} catch (SQLException e) {
		
			e.printStackTrace();
			mylogger.error("All Data not Displayed");
			
			try {
				throw new MobileException("Data not Found");
			} catch (MobileException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		}finally{
			
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
		}
		return mList;
	}

	@Override
	public boolean deleteMobile(int mobileid) {
	
			try {
				conn=JdbcUtil.getConnection();
			} catch (MobileException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			int rec=0;
			String query = "DELETE FROM mobiles WHERE mobileid=?";
			try {
				pst=conn.prepareStatement(query);
				pst.setInt(1, mobileid);
				 rec = pst.executeUpdate();
				if(rec>0){
					mylogger.info("Data is deleted");
					return true;
					
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				mylogger.error(" Data Not Deleted");
				
			}
			finally{
				
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					
					
				}
			}
		
		return false;
	}

	@Override
	public List<Mobile> searchByRange(int start, int end) {
		
		List<Mobile>mList=new ArrayList<Mobile>();
		try {
			conn=JdbcUtil.getConnection();
		} catch (MobileException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String query="SELECT * FROM mobiles WHERE price >=? AND price <=?";
		try {
			pst=conn.prepareStatement(query);
			pst.setInt(1, start);//first qsn mark
			pst.setInt(2, end);
			ResultSet rs=pst.executeQuery();
				while(rs.next()){
				
				int m_id=rs.getInt(1); //either pass index(always starts with 1) or columnname in double quotes
				String m_names = rs.getString(2);
				double m_prices=rs.getInt(3);
				int m_qty=rs.getInt(4);
				Mobile m = new Mobile();
				m.setMobileid(m_id);
				m.setMobilename(m_names);
				m.setQuantity(m_qty);
				mList.add(m);
				
			
		} mylogger.info("Data is searched");
		}catch (SQLException e) {

			e.printStackTrace();
			mylogger.error("data is not searched");
		}
		
		
		return mList;
	}
	
	public static void main(String args[]){
		
		MobileDaoImpl impl = new MobileDaoImpl();
		List<Mobile>mList=impl.showAll();
		//List<Mobile>mList=impl.searchByRange(8000,15000);
		
		for(Mobile m:mList){
			
			System.out.println(m);
		}
	}

	@Override
	public boolean updateQty(int mobileid, int qty) throws MobileException {
		conn=JdbcUtil.getConnection();
		int rec=0;
		int qty1=0;
		String selectquery="Select quantity from mobiles where mobileid=?";
		String query="UPDATE MOBILES SET quantity=quantity-? WHERE mobileid=?";
		try {
			pst=conn.prepareStatement(selectquery);
			pst.setInt(1,mobileid);
			ResultSet rs=pst.executeQuery();//select query executed here
			while(rs.next()){
			 qty1=rs.getInt(1);//returns the value of quantity column and stores in qty1
			 System.out.println(qty1);
			 
				
			}
			
			
		} catch (SQLException e1) {
			
			e1.printStackTrace();
		}
		
	try{
		if(qty1>qty){
		pst=conn.prepareStatement(query);
		pst.setInt(1,qty);
		pst.setInt(2,mobileid);
		rec=pst.executeUpdate();
		if (rec>0)
		{ 
			 mylogger.info("Data is Updated");
			// System.out.println("Remaining Quantity:"+(qty1-qty));
			return true;
		}
	}else{
		
		System.out.println("quantity you have entered is greater than quantity in database");
	}
	}catch (SQLException e) {

		e.printStackTrace();
		mylogger.error("data is not updated");
		throw new MobileException("data is not updated");
		
	}
	return false;
}

	@Override
	public boolean Mobileid(int mid) throws MobileException {
		conn=JdbcUtil.getConnection();
		int id=0;
		String query="SELECT count(mobileid) FROM mobiles WHERE mobileid=?";
		try{
			
			pst=conn.prepareStatement(query);
			pst.setInt(1,mid);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				
				id =rs.getInt(1);
				
			}
			
			if(id==1){
			return true;	
			
			}
			else{
				throw new MobileException("mobile id not exist");
				
			}
			}catch(SQLException e){
				 System.out.println(e);
				e.printStackTrace();
				//throw new MobileException("mobile id not exixt");
				
			}
			
		
		
		return false;
	}
	
	
public boolean insertPurchaseDetails(String cust_name,String cust_mail,String cust_phone,int mobileid) throws PurchaseDetailsException{
		
		try {
			conn=JdbcUtil.getConnection();
		} catch (MobileException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int qty = 0;
		int rec=0;
		String iquery="INSERT INTO PurchaseDetails VALUES(purchase_seq.NEXTVAL,?,?,?,sysdate,?)";
		String squerry="SELECT quantity FROM mobiles WHERE mobileid=?";
		try {
			pst = conn.prepareStatement(squerry); //add try catch block
			pst.setInt(1,mobileid);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				qty=rs.getInt(1);//to check qty>0 first take qty by get() then do insert
				System.out.println("Exsisting quantity:"+qty);
				
			}
			
			if(qty>0){
				
				pst=conn.prepareStatement(iquery);
				pst.setString(1, cust_name);
				pst.setString(2, cust_mail);
				pst.setString(3,cust_phone);
				pst.setInt(4, mobileid);
				
				PurchaseDetails pd = new PurchaseDetails();
				pd.setCname(cust_phone);
				pd.setMailid(cust_mail);
				pd.setPhoneno(cust_phone);
				pd.setMobileid(mobileid);
				
				rec=pst.executeUpdate();// insert query will be executed here
				if(rec>0){
					return true;
				}
				
			}
		}catch(SQLException e){
			
			e.printStackTrace();
			throw new PurchaseDetailsException("data not inserted");
		}
			
		return false;
	}

}

