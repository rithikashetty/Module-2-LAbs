package com.cg.ma.ui;

import java.util.List;

import java.util.Scanner;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ma.dto.Mobile;
import com.cg.ma.exception.MobileException;
import com.cg.ma.exception.PurchaseDetailsException;
import com.cg.ma.service.IMobileService;
//import com.cg.ma.service.IPurchaseDetailsService;
import com.cg.ma.service.MobileServiceImpl;
//import com.cg.ma.service.PurchaseDetailsServiceImpl;
import com.cg.ma.util.JdbcUtil;

public class MobileApplication {
	
	private static final Logger mylogger=Logger.getLogger(JdbcUtil.class);

	public static void main(String[] args) throws MobileException, PurchaseDetailsException {
		
		PropertyConfigurator.configure("log4j.properties");
		mylogger.info("Application Started");
		System.out.println("Start");
		
		IMobileService iMobService = new MobileServiceImpl();
		//IPurchaseDetailsService iPurchasedetail = new PurchaseDetailsServiceImpl();
		
		int choice=0;
		do{
			printDetails();
			Scanner sc = new Scanner(System.in);
			choice =sc.nextInt();
			switch(choice){
			
			case 1:
				
				List<Mobile> mList = iMobService.showAllMobiles();
				for(Mobile m:mList){
					System.out.println("mobileid="+m.getMobileid()+"Mobile Name="+m.getMobilename()+"Price="+m.getPrice()+"quantity="+m.getQuantity());
					
					
					
				}
				break;
				
			case 2:
				
				System.out.println("Enter minimum Price");
				int start=sc.nextInt();
				System.out.println("Enter Maximum Price");
				int end=sc.nextInt();
				List<Mobile> mList2 = iMobService.searchByRange(start, end);
				for(Mobile m:mList2){
					System.out.println("mobileid="+m.getMobileid()+"Mobile Name="+m.getMobilename()+"Price="+m.getPrice()+"quantity="+m.getQuantity());

			
			}
				break;
			

			
			case 3:
				boolean checkmid = false;
				String regName = "[A-Z]+[a-z]{1,19}";
				String regEmail = "(.+)@(.+)[.]{1}(.+)$";
				String regPhone = "[7|8|9]{1}[0-9]{9}";
				String regMoid = "^[1-9]{1}[0-9]{3}";
				
				System.out.println("Enter Customer Name");
				String cname= sc.next();
				
				System.out.println("Enter email id");
				String mailid= sc.next();
				
				System.out.println("Enter Phone no");
				String phoneno= sc.next();	
			
				System.out.println("Enter mobile id");
				String mobileid= sc.next();	
				
				
				
				boolean checkname = Pattern.matches(regName, cname);
				boolean checkmailid = Pattern.matches(regEmail,mailid);
				boolean checkphoneno = Pattern.matches(regPhone, phoneno);
				boolean checkmobileid = Pattern.matches(regMoid, mobileid);
				
				int mid =Integer.parseInt(mobileid);
				if(checkmobileid==true){
					
					checkmobileid =iMobService.Mobileid(mid);
					
					
				}
				
				if((checkname==true)&&(checkmailid==true)&&(checkphoneno==true)&&(checkmobileid==true)){
					
					iMobService.insertPurchaseDetails(cname, mailid, phoneno, mid);
					System.out.println("Data added successfully");
					iMobService.updateQty(mid,1);

				}
				else{
					
					System.out.println("Customer Name"+checkname +"email id"+checkmailid+"Phone No:"+checkphoneno+"Mobile id:"+checkmobileid);
					System.out.println("Enter Proper Customer Details");
					
				}
				
				break;
				
				
			case 4:
				
				System.out.println("Enter mobile id");
				int mid1=sc.nextInt();
				System.out.println("Enter Purchase quantity");
				int qty =sc.nextInt();
				iMobService.updateQty(mid1, qty);
				System.out.println("mobile quantity updated");
				break;
				
			case 5:
				
				System.out.println("enter mobile id");
				int mid2 = sc.nextInt();
				boolean str = iMobService.deleteMobile(mid2);
				if(str==true){
					
					System.out.println("mobile details deleted");
				}
				
				break;
				
			case 6:
				
				PropertyConfigurator.configure("log4j.properties");
				mylogger.info("Application ended");
				System.out.println("end");
				break;
				
			default:
				System.out.println("enter choice between 1 to 6");
		}
		
		
		

	}while(choice!=6);
	}

	private static void printDetails() {
		
		
		System.out.println("*********************");
		System.out.println("Enter Choice");
		System.out.println("1.Show all Mobile Details");
		System.out.println("2.Search Mobile Details by Price Range");
		System.out.println("3.Insert Customer and purchase details");
		System.out.println("4.update mobile quantity");
		System.out.println("5.delete mobile details");
		System.out.println("6.exit");
		System.out.println("*********************");
		
	}

}
