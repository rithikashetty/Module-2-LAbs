package com.cg.ma.JunitTest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.ma.dao.IMobileDao;
import com.cg.ma.dao.MobileDaoImpl;
import com.cg.ma.exception.MobileException;

public class Test2MobileDaoImpl {
	IMobileDao imobile;//local variable created


	@Before
	public void setUp() throws Exception {
		
	 imobile = new MobileDaoImpl();//create local variable
	}

	@After
	public void tearDown() throws Exception {
		
		imobile=null;
	}

	@Test
	public void testDeleteMobile() throws MobileException {
		
		assertEquals(true,imobile.Mobileid(1001));
		
	}

	@Test
	public void testSearchByRange() throws MobileException {
		assertNotNull(imobile.searchByRange(8000, 3000));
	}

	@Test
	public void testUpdateQty() throws MobileException {
		
		assertEquals(true,imobile.updateQty(1001, 5));//enter id which is present in database
		
	}

}
