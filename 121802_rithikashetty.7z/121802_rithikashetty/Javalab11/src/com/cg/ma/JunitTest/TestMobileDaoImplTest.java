package com.cg.ma.JunitTest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.cg.ma.dao.IMobileDao;
import com.cg.ma.dao.MobileDaoImpl;
import com.cg.ma.exception.MobileException;

public class TestMobileDaoImplTest {
	
	IMobileDao imobile;
	
	@AfterClass
	public static void tearDownAfterClass()throws Exception{
		
		
	}
	@Before
	public void setUp() throws Exception {
		
		imobile = new MobileDaoImpl();
	}

	@Test
	public void testShowAll() {
	
		try {
			assertNotNull(imobile.showAll());
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//assertNotNull(imobile.deleteMobile(1002));
		
	}

	@After
	public void tearDown() throws Exception {
		
		imobile=null;
	}


}
