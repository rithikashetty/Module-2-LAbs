package com.cg.ma.util;

import java.io.FileInputStream;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ma.util.JdbcUtil;
import com.cg.ma.exception.MobileException;

public class JdbcUtil {
	private static final Logger mylogger=Logger.getLogger(JdbcUtil.class);
	public static Properties loadProperty(){
		
		Properties prop = new Properties();
		InputStream in =null;
		
		try {
			in = new FileInputStream("oracles.properties");
			prop.load(in);
			
		} catch (FileNotFoundException e) {
		
			e.printStackTrace();
		}
		
		catch (IOException e) {
			
			e.printStackTrace();
		}
		
		finally{
			
			try{
				
				in.close();
			}
			
			catch(IOException e){
				
				e.printStackTrace();
			}
		}
		return prop;
		
		
	}
	
	
	public static Connection getConnection() throws MobileException{
		
		Connection conn= null;
		Properties prop = loadProperty();
		String url= prop.getProperty("oracle.url");
		String driver = prop.getProperty("oracle.driver");
		String user=prop.getProperty("oracle.uname");
		String password=prop.getProperty("oracle.upass");
		

	try{
	Class.forName(driver);
	mylogger.info("Driver is Loaded");
	}
	catch(ClassNotFoundException e){
		
		e.printStackTrace();
		mylogger.error("Driver is not Loaded");
	}
	try{
	conn= DriverManager.getConnection(url,user,password);
	mylogger.info("Connected to the database");
	}catch(SQLException e){
		
		e.printStackTrace();//will show in console part
		mylogger.error("Not Connected");
		throw new MobileException("Connection problem.Please try latter");
	}
	return conn;
}
	
/*	 public static void main(String[] args){
	 
	 JdbcUtil j = new JdbcUtil();
	 PropertyConfigurator.configure("log4j.properties");
	 try{
	 	j.getConnection();
	 }catch(MobileException e){
	 
	 e.printStackTrace();
	 }
	 
	 }*/
	 
 
	
}
