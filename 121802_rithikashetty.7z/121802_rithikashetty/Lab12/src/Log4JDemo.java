import org.apache.log4j.Logger;



public class Log4JDemo {
	
	public static final Logger myLogger= 
			Logger.getLogger(Log4JDemo.class);

	public static void main(String[] args) {
	
		myLogger.debug("This is my debug message");
		myLogger.info("This is my info message");
		myLogger.warn("This is  my warn message");
		myLogger.error("This is  my Error message");
		myLogger.fatal("This is my fatal message");

	}

}
