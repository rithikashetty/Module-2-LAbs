import java.util.ArrayList;
import java.util.Collections;


public class ArrayList7_2 {

	public static void main(String[] args) {
		
		ArrayList<String> alist = new ArrayList<String>();
		alist.add("mobile");
		alist.add("computer");
		alist.add("Television");//capital letters will come first in sorting
		alist.add("mouse");
		
		System.out.println("Before Sorting");
		
		for(String s:alist){
			System.out.println(s);
			
		}
		
		System.out.println("After Sorting");
		
		Collections.sort(alist);
		
		for(String s:alist){
			System.out.println(s);
			
		}
		
		
	}

}
