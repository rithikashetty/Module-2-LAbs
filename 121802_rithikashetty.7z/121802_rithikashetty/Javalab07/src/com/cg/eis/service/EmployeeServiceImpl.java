package com.cg.eis.service;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.cg.eis.bean.Employee;


public class EmployeeServiceImpl implements IEmploymentService {

	HashMap<String, Employee> empMap = new HashMap<String, Employee>();
	
	public void inputEmployee(){
		
		
		
		Employee e = new Employee(101,"Rithika",20000,"Programmer");
		empMap.put("Scheme C", e);
		
		Employee e1 = new Employee(102,"Purvi",30000,"System Assosiate");
		empMap.put("Scheme B", e1);
		
		Employee e2 = new Employee(103,"Prithvi",4000,"Manager");
		empMap.put("Scheme A", e2);
	
		Set set = empMap.entrySet();                 // Get a set of the entries
		Iterator i = set.iterator();                       // Get an iterator
		while(i.hasNext()) 
		{                       // Display elements
			Map.Entry me = (Map.Entry)i.next();
			System.out.println(me.getKey() + ": "+ me.getValue());	
		}
		//System.out.println(empMap);
	}
 
 
	public void deleteDetails() {
		
		
		empMap.remove("Scheme C");
		System.out.println(empMap);
		
	}
	
}
