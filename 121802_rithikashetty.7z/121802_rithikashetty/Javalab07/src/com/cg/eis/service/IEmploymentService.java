package com.cg.eis.service;

public interface IEmploymentService {

	public void inputEmployee();

	public void deleteDetails();

}
