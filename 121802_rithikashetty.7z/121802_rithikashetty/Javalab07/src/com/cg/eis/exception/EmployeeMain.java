package com.cg.eis.exception;

import com.cg.eis.service.EmployeeServiceImpl;
import com.cg.eis.service.IEmploymentService;


public class EmployeeMain {

	public static void main(String[] args) {


		 IEmploymentService empservice = new EmployeeServiceImpl();
		 empservice.inputEmployee();
		  empservice.deleteDetails();

		
	}

}
