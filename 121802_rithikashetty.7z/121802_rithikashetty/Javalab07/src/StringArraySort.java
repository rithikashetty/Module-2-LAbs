import java.util.Arrays;




public class StringArraySort {

	
	
	public static void main(String[] args) {
	
			String productnames[]={"pbc","cde","zzz"};
			for(String s:productnames){
				
				System.out.println(s);
			}
			System.out.println("array after sort");
			Arrays.sort(productnames);
			for(int i=0;i<productnames.length;i++){
				System.out.println(productnames[i]);
				
			}
	}

}
