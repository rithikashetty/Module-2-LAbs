import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class ReadFileContent {

	public static void main(String[] args) {
		

			try(FileReader in = new FileReader("d:\\myword.txt");
				FileWriter out = new FileWriter("d:\\copypath.txt")) {
				File f = new File("d:\\myword.txt");
				int len=(int)f.length();
				char arr[] = new char[len];
				int i=0;
				int ch = in.read();
				while(ch!=-1){
					arr[i]=(char)ch;
					i++;
					ch=in.read();
				}
				for(int j=len-1;j>0;j--){
					System.out.print(arr[j]);
					out.write(arr[j]);	
			}
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
			
		} 
			catch (IOException e) {


			e.printStackTrace();
		}
		}
	}


