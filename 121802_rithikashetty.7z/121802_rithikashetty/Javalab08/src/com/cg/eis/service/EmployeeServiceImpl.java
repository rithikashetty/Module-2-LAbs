package com.cg.eis.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.SalaryException;

public class EmployeeServiceImpl implements IEmploymentService {


	 int id;
	 String name;
	 double salary;
	 String designation;
	 String insuranceScheme = null;
	 Employee e;
	 
	public void inputEmployee(){
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Enter id of Employee");
	id=sc.nextInt();
	
	System.out.println("Enter name of Employee");
	name=sc.next();	
	
	System.out.println("Enter salary of Employee");
	salary=sc.nextDouble();
	
	System.out.println("Enter Designation ");
	designation=sc.next();
	
	try {
		e = new Employee(id,name,salary,designation);
	} catch (SalaryException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}


	public void findInsuranceScheme() {
		
		double salary=e.getSalary();
		String designation = e.getDesignation();
		
		if(((salary>5000)&&(salary<2000))&&(designation.equals("System Associate"))){
			
			
			 insuranceScheme = "Scheme C";
			
		}
		else if(((salary>=20000)&&(salary<40000))&&(designation.equals("Programmer")))
		{
			
			 insuranceScheme = "Scheme B";
			
		}
		
		
		else if((salary>=40000)&&(designation.equals("Manager"))){
			
			insuranceScheme = "Scheme A";
			
		}
		
		else if((salary<5000)&&(designation.equals("Clerk"))){
			
			insuranceScheme = "No Scheme";
			
		}
		
		e.setInsuranceScheme(insuranceScheme);
		
	}

	public void writeData(){

		try(FileOutputStream out = new FileOutputStream("d://empdetails.txt");
		ObjectOutputStream sout = new ObjectOutputStream(out);) {
			Employee emp[]={new Employee(id,name,salary,designation)};
			
			for(int i=0;i < emp.length;i++){
				
				sout.writeObject(emp[i]);
			}
			
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e2) {
			e2.printStackTrace();
		} catch (SalaryException e) {
			e.printStackTrace();
		}
		
		
		
	}
	
	public void readData(){
		
		
		try(FileInputStream in =new FileInputStream("d://empdetails.txt");
				ObjectInputStream sin = new ObjectInputStream(in);) {
			
			Employee e = (Employee) sin.readObject();
			e.display();
			sin.close();
		
			
			 
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
	}

	public void displayDetails() {
		e.display();
		
	}
	
	/*public void showDetails(){
		System.out.println("id	:" + id);
		System.out.println("Name	:" + name);
		System.out.println("Salary	:" + salary);
		System.out.println("Designation	:" + designation);
	}*/
	
}
