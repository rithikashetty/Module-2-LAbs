import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;




public class ScannerDemo {

	public static void main(String[] args) {
			
			try{
				File  f = new File("d:\\numbers.txt");
				Scanner sc = new Scanner(f);
				sc.useDelimiter(",");
				while(sc.hasNext()){
					if(sc.hasNextInt()){
						
						int i = sc.nextInt();
						if(i%2==0 && i !=0){
							
							System.out.println(i);
							
						}
						
					}
					
				}

	}
			catch (FileNotFoundException e) {
				
				e.printStackTrace();
				
			} 
			
	}
}

