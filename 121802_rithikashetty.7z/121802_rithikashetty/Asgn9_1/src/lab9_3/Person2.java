package lab9_3;

public class Person2 {

	String firstname;
	String lastname;
	char gender;
	
	
	public Person2() {
		super();
	}
	
	
	public Person2(String firstname, String lastname, char gender) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
	}


	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}


	
	public String displayDetails() {
		
		String ret= "Person Detail: "+firstname+" "+lastname+" "+gender;
		return ret;
	}
	
	
	
}
