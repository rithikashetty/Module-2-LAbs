package com.cg.eis.Exception;

public class EmployeeException extends Exception {
	
	public EmployeeException(String S){
		super(S);
		String msg= S;
		System.out.println(msg);
	}
	
	

}
