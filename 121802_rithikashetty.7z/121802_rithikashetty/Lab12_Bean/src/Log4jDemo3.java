import org.apache.log4j.Logger;


public class Log4jDemo3 {

	public static final Logger myLogger= 
			Logger.getLogger(Log4jDemo3.class);
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Message msg= new Message();
		msg.setMessage("Hello..message");
		
		myLogger.info("Welcome to logger");
		myLogger.debug("Welcome to logger");
		myLogger.fatal("Welcome to logger");
		myLogger.warn("Welcome to logger");
		myLogger.error("Welcome to logger");
		
	
		System.out.println(msg.getMessage());
		
	}
	
}
