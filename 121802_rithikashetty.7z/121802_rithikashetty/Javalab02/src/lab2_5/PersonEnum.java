package lab2_5;

public class PersonEnum {
	 String firstname;
	 String lastname;
	 Gender gender;
	 String phonenum;

		public PersonEnum(String firstname, String lastname, Gender gender,
			String phonenum) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
		this.phonenum = phonenum;
	}
		public PersonEnum() {
			super();
			
		}
	
	
public String getPhonenum() {
			return phonenum;
		}
		public void setPhonenum(String phonenum) {
			this.phonenum = phonenum;
		}
public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
void show(){
	
	
	System.out.println("First Name:" +firstname);
	System.out.println("Last Name:" +lastname);
	System.out.println("Gender:" +gender);
	System.out.println("Phone Number:"+phonenum);
}

}
