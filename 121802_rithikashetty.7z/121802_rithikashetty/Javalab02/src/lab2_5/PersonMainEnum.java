package lab2_5;

import java.util.Scanner;


public class PersonMainEnum {

	public static void main(String[] args) {
		Gender gender=null;
		
		PersonEnum pe =new PersonEnum();
		
		pe.setFirstname("Rithika");
		
		pe.setLastname("Shetty");
		
		System.out.println("Enter Phone Number");
		
		Scanner sc = new Scanner(System.in);
		
		String phonenum = sc.nextLine();
		
		pe.setPhonenum(phonenum);
		
			System.out.println("Enter Gender:");
			
		String m_gender = sc.nextLine();       //contains string(m_gender)
		
		gender = gender.valueOf(m_gender);     // to convert string into enum
		
		pe.setGender(gender);
				
		pe.show();	
	}

}
