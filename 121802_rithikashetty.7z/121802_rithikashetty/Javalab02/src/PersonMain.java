
public class PersonMain {

	public static void main(String[] args) {
		Person p =new Person("Rithika","Shetty",'F');
		System.out.println("First Name:"+p.getFirstname());
		System.out.println("Last Name:"+p.getLastname());
		System.out.println("Gender:" +p.getGender());
	}

}
