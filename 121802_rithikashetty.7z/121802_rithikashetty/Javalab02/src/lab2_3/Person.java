package lab2_3;

import java.time.LocalDate;
import java.time.Period;

public class Person {

	 String firstname;
	 String lastname;
	 char gender;
	 String phonenum;
	 
	 
	 
	public Person() {
		super();
	}

	public Person(String firstname, String lastname, char gender) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public String getPhonenum() {
		return phonenum;
	}

	public void setPhonenum(String phonenum) {
		this.phonenum = phonenum;
	}
	
	public void display(){
		
		System.out.println("First Name:" +firstname);
		System.out.println("Last Name:" +lastname);
		System.out.println("Gender:" +gender);
		System.out.println("Phone Number:"+phonenum);
	}
	


}
