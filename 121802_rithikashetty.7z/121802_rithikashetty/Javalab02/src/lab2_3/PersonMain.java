package lab2_3;

import java.util.Scanner;

public class PersonMain {
	
	public static void main(String[] args){
		
	Person person = new Person("Rithika","Shetty",'F');
	System.out.println("Enter Phone Number");
	Scanner sc = new Scanner(System.in);
	String phonenum = sc.nextLine();
	person.setPhonenum(phonenum);
	person.display();
	
	}
	
	
}
