package lab3_2;
import java.util.Scanner;

public class StringObjectMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter String");
		String str = sc.nextLine();
		int choice;

		System.out.println("1.Add the String to itself");
		System.out.println("2.Replace odd positions with #");
		System.out.println("3.Remove duplicate characters in the String");
		System.out.println("4.Change odd characters to upper case");
		System.out.println("Enter options");
		choice = sc.nextInt();
		StringOperation strop = new StringOperation();
		strop.display(str,choice);
		
		
		
	}

}
