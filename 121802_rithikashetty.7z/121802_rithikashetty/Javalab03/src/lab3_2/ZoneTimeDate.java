package lab3_2;

import java.time.ZoneId;

import java.time.ZonedDateTime;
import java.util.Scanner;

public class ZoneTimeDate {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("1.America/New_York");
		System.out.println("2.Europe/London");
		System.out.println("3.Asia/Tokyo");
		System.out.println("4.US/Pacific");
		System.out.println("5.Africa/Cairo");
		System.out.println("6.Australia/Sydney");
		
		System.out.println("Enter choice");
		int ch=sc.nextInt();
		
		switch(ch){
		
		case 1:
			ZonedDateTime currentTimeInAmericaNewYork = ZonedDateTime.now(ZoneId.of("America/New_York"));
			System.out.println("America/NewYork:"+ currentTimeInAmericaNewYork);
			break;
			
		case 2:
			ZonedDateTime currentTimeInEuropeLondon = ZonedDateTime.now(ZoneId.of("Europe/London"));
			System.out.println("Europe/London:"+currentTimeInEuropeLondon);
			break;
			
		case 3:	
			ZonedDateTime currentTimeInAsiaTokyo = ZonedDateTime.now(ZoneId.of("Asia/Tokyo"));
			System.out.println("Asia/Tokyo"+currentTimeInAsiaTokyo);
			break;
			
		default:
			System.out.println("invalid Input");
		}
		

	}

}
