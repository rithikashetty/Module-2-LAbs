package lab3_2;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class DateDurationtwo {
	
	public static void calculatePeriod(String sdate,String sdate2){
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate givenDate =  LocalDate.parse(sdate,formatter);
		LocalDate givenDate2 =  LocalDate.parse(sdate2,formatter);
		Period period = givenDate2.until(givenDate);
		
		System.out.println("Days:"+ period.getDays());
		System.out.println("Months:"+period.getMonths());
		System.out.println("Years:"+ period.getYears());
	}

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first date in format dd-MM-yyyy");
		String stringDate=sc.nextLine();
		System.out.println("Enter the second date in format dd-MM-yyyy");
		String stringDate2=sc.nextLine();
		calculatePeriod(stringDate,stringDate2);
	
	
	}
		
		
		
	}

