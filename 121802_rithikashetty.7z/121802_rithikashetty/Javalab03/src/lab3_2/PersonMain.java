package lab3_2;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;


public class PersonMain {

	public static void main(String[] args) {
		Person person = new Person("Rithika","Shetty",'F');
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter date of birth");
		
		String dob = sc.nextLine();
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		
		LocalDate dateofbirth =  LocalDate.parse(dob,formatter);
		
		person.setDateOfBirth(dateofbirth);
		
		person.display();
		
		person.calculateAge(dateofbirth);
		
		//System.out.println("Enter first name:");
		
		
		

	}

}

