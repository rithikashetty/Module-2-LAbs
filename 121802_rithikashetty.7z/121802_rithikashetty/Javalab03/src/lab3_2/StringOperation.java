package lab3_2;

public class StringOperation {


	
	void display(String str,int ch){
		String newstring;
		
		String temp;
		switch(ch)
		{
		case 1:
			
			newstring = str+str;
			System.out.println(newstring);
			break;
			
		case 2:
		    int	strlength =str.length();
			for(int i=0;i<strlength;i++)
			{
				if(i%2 !=0){
					str=str.substring(0,i-1) + "#" + str.substring(i,strlength);
				}
				
			}
			System.out.println(str);
			
			break;
			
		case 3:
			
			
			break;
		
		case 4:
			String neword="";
			 int stringlength =str.length();
			for(int i=0;i<stringlength;i++)
			{
				if(i%2 !=0){
					
					temp="";
					temp=temp+str.charAt(i);
					temp=temp.toUpperCase();
					neword=str.substring(i)+temp;
					
				}
				
			}
			
			System.out.println(neword);
			break;
		}
		
		
	}
}
