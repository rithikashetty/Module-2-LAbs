package lab3_2;

import java.util.Scanner;

public class StringOrderMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter string");
		
		String str = sc.nextLine();
		
		StringPositiveOrder spo = new StringPositiveOrder();
		
		boolean result = spo.stringOrder(str);
		
		System.out.println(result);

	}

}
