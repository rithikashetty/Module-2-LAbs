package lab3_2;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class DateDuration {
	
	public static void calculatePeriod(String sdate){
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate givenDate =  LocalDate.parse(sdate,formatter);
		System.out.println("Given Date"+givenDate);
		LocalDate today =LocalDate.now();
		System.out.println("Today:"+today);
		Period period = givenDate.until(today);
		
		System.out.println("Days:"+ period.getDays());
		System.out.println("Months:"+period.getMonths());
		System.out.println("Years:"+ period.getYears());

		
	}

	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the date in format dd-MM-yyyy");
		String stringDate=sc.nextLine();
	
		//String stringDate="01-01-2017";
		calculatePeriod(stringDate);
		

	}

}
