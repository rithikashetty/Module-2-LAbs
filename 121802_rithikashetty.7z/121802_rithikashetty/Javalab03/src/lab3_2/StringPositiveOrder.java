package lab3_2;

public class StringPositiveOrder {

	public boolean stringOrder(String str){
			//String str1 = str.toLowerCase();
		//System.out.println(str1);
		
		int ctr=0;
		for(int i=0;i<str.length()-1;i++){
			ctr=0;
			if((int)str.charAt(i) < (int)str.charAt(i+1)){
				
				ctr=1;
				
			}
			else ctr=0;
		}
		
		if(ctr==1)
			return true;
		
		else return false;
		
		}
}
