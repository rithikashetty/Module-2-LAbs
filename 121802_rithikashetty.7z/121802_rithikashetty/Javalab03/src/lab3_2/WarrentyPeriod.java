package lab3_2;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class WarrentyPeriod {
	

	public static void main(String[] args) {
		

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the product purchase date in format dd-MM-yyyy");
		
		String prdPurchaseDate=sc.nextLine();
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		
		LocalDate givenPurchaseDate =  LocalDate.parse(prdPurchaseDate,formatter);
		
		System.out.println("Enter the warrentee period in terms of months and years");
		int expMonth=sc.nextInt();
		int expYears=sc.nextInt();
		
		LocalDate date2=givenPurchaseDate.plusMonths(expMonth);
		LocalDate date3=date2.plusYears(expYears);
		
		System.out.println("Expiry Date:"+date3);
	}

}
