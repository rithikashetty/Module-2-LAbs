package lab3_2;

import java.time.LocalDate;
import java.time.Period;

public class Person {

	 String firstname;
	 String lastname;
	 LocalDate dateofbirth;
	 char gender;
	 
	public Person(String firstname, String lastname,char gender) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender=gender;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public LocalDate getDateOfBirth() {
		return dateofbirth;
	}
	public void setDateOfBirth(LocalDate dateofbirth) {
		this.dateofbirth = dateofbirth;
	}
	
public void display(){
		
		System.out.println("First Name:" +firstname);
		System.out.println("Last Name:" +lastname);
		System.out.println("Gender:" +gender);
		System.out.println("Date Of Birth:"+dateofbirth);
	}
public void calculateAge(LocalDate dateofbirth){
	
	LocalDate today = LocalDate.now();
	Period period = dateofbirth.until(today);
	System.out.println("Age:" +period.getYears() + "yrs");
	
}
 

}
