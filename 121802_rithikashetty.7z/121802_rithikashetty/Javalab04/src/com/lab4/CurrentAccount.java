package com.lab4;

public class CurrentAccount extends Account {

	@Override
	public void withdraw(double amount) {
		
		super.withdraw(amount);
	}

}
