package com.lab4;

public class AccountMain {

	public static void main(String[] args) {
		
		Person smith =  new Person("smith",23);
		
		Person kathy = new Person("kathy",25);
		
		Account accountsmith = new Account(2000);
		
		accountsmith.setAccnHolder(smith);
		
		accountsmith.deposit(2000);
		
		System.out.println(accountsmith);
		
		System.out.println("Updated Balance of Smith:" +accountsmith.getBalance());
		
		Account accountkathy = new Account(3000);
		
		accountkathy.setAccnHolder(kathy);
		
		accountkathy.withdraw(2000);
		
		System.out.println(accountkathy);
		
		System.out.println("Updated balance of kathy:"+accountkathy.getBalance());
		
		SavingsAccount saving = new SavingsAccount(600); 
		saving.withdraw(200);
		

	}

}
