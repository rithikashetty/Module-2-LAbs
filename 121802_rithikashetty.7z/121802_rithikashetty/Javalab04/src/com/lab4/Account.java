package com.lab4;

public class Account {

	private long accNum;//if acnt no is static then same acnt no will be assigned to everyone
	private double balance;
	private Person accnHolder;
	static int count=10000;
	public Account(){
		
		super();
		count++;
		accNum=count;
		
	}
	public void deposit(double amount){
		
		balance=balance+amount;
		
	}
	public void withdraw(double amount){
		if(balance-amount>=500){
			balance=balance-amount;
		}else{
			
			System.out.println("Insuufficient balance");
		}
		
		
	}
	
	public double getBalance(){
		return balance;
				
	}
	public long getAccNum() {
		return accNum;
	}
	public Person getAccnHolder() {
		return accnHolder;
	}
	
	public Account(double balance) {
		super();
		count++;
		this.accNum = count;
		this.balance = balance;
	}
	
	public void setAccnHolder(Person accnHolder) {
		this.accnHolder = accnHolder;
	}
	/*public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance
				+ ", accnHolder=" + accnHolder + "]";
	} */
	
}
