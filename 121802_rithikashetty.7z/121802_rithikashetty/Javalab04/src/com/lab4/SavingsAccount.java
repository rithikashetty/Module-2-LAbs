package com.lab4;

public class SavingsAccount extends Account {
	final double minimumbalance=500;
	private double bal;
	
	public SavingsAccount(double bal){
		
		super(bal);
		this.bal=bal;
	}

	@Override
	public void withdraw(double amount) {
		
		if(bal-amount>=minimumbalance){
		super.withdraw(amount);
		}else{
			System.out.println("Insufficient Balance");
		}
	}

}
