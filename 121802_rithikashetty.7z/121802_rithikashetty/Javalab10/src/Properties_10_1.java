import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;


public class Properties_10_1 {
		
	public void readProperties(){
		
		Properties prop = new Properties();
		InputStream input = null;
		
		try {
			input = new FileInputStream("PersonProps.properties");
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		
		try {
			prop.load(input);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println(prop.getProperty("oracle.driver"));
		System.out.println(prop.getProperty("oracle.url"));
		System.out.println(prop.getProperty("oracle.user"));
		System.out.println(prop.getProperty("oracle.pass"));
		
		
	}
	
	public void writeProperties(){
	Properties prop = new Properties();
	OutputStream output = null;
	
	prop.setProperty("oracle.driver","oracle.jdbc.driver.OracleDriver");
	prop.setProperty("oracle.url","oracle:thin:@localhost:1521:xe");
	prop.setProperty("oracle.user","labg104trg7@orcl11g");
	prop.setProperty("oracle.user","labg104oracle");
	
	try {
		output=new FileOutputStream("PersonProps.properties");
	} catch (FileNotFoundException e1) {
		e1.printStackTrace();
	}
	try {
		prop.store(output,null);
	} catch (IOException e) {
		e.printStackTrace();
	}
	}
	
	public static void main(String[] args) {
		Properties_10_1 preclass = new Properties_10_1();
		preclass.writeProperties();
		preclass.readProperties();
		
	}

}
