package com.cg.eis.pl;

import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.EmployeeServiceImp1;

public class EmpApp {

	public static void main(String[] args) {
		EmployeeService service = new EmployeeServiceImp1();
		
		service.addEmployee();
		service.ShowAllData();
		service.DeleteData(102);
	}
}
