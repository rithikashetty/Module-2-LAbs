package com.cg.eis.service;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class Jdbcutil  {
public static Properties loadProperty(){ 	//return type is Properties
			Properties prop = new  Properties();
			InputStream in = null;					//read oracle.properties file
			
			try {
				in= new FileInputStream("oracle.properties");
				prop.load(in);
				
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				try {
					in.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}return prop;
		}
		public static Connection getConnection() {
			Connection con = null;
			Properties prop =  loadProperty();
			String url = prop.getProperty("oracle.url");
			String driver = prop.getProperty("oracle.driver");
			String user = prop.getProperty("oracle.uname");
			String password = prop.getProperty("oracle.upass");
			
			try {
				Class.forName(driver);
				con = DriverManager.getConnection(url,user,password);
				
			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
								}
			
					
			return con;

		}
}
