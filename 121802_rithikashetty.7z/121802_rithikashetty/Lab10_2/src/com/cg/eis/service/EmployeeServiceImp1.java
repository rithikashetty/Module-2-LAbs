package com.cg.eis.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.eis.bean.Employee;



public class EmployeeServiceImp1 implements EmployeeService{
	
	Employee emp;
	Connection con;
	PreparedStatement pst;
		
	public boolean addEmployee() {
		
		@SuppressWarnings("resource")
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter number of Employees: ");
		int n = sc.nextInt();
		
		for (int i = 0; i < n; i++) {
			
		System.out.println("Enter id: ");
		int id=sc.nextInt();
		System.out.println("Enter name: ");
		String name=sc.next();
		System.out.println("Enter Salary: ");
		double salary=sc.nextDouble();
		System.out.println("Enter designation: ");
		String designation=sc.next();
				
		con = Jdbcutil.getConnection();
		int rec = 0;
		String query = "Insert into employee10_2 values(?,?,?,?)";
		try {
				pst = con.prepareStatement(query);
				pst.setInt(1, id);
				pst.setString(2, name);
				pst.setDouble(3, salary);
				pst.setString(4, designation);
				
				rec = pst.executeUpdate();
				if (rec > 0){
					return true;
					}
			} catch (SQLException e) {
				e.printStackTrace();
			
			}

		}return false;
}
		
	@Override
	public List<Employee> ShowAllData(){
			
		con = Jdbcutil.getConnection();
		String query = "SELECT * from employee10_2";

		List<Employee> mlist = new ArrayList<Employee>();
		try {
			pst = con.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				int m_id = rs.getInt(1);
				String m_name = rs.getString(2);
				double m_salary = rs.getInt(3);
				String m_designation = rs.getString(4);
				Employee m = new Employee();
				m.setId(m_id);
				m.setName(m_name);
				m.setSalary(m_salary);
				m.setDesignation(m_designation);
				mlist.add(m); // add object m to arraylist mlist
				}
			
			for (Employee e : mlist) {
				System.out.println(e);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} finally {
		}
		try {
			pst.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
			
		}
		return mlist;

	}

	@Override
	public boolean DeleteData(int id) {
		con = Jdbcutil.getConnection();
		String query = "DELETE FROM employee10_2 where id=?";
		try {
			pst = con.prepareStatement(query);
			pst.setInt(1, id);
			int rec = pst.executeUpdate();
			if (rec > 0){
					
					return true;
				}
		} catch (SQLException e) {
			e.printStackTrace();
	} finally {

			try {
								pst.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
		}
		return false;}
}
	
		
		


