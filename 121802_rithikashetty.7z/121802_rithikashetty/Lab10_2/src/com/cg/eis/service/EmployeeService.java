package com.cg.eis.service;

import java.util.List;

import com.cg.eis.bean.Employee;

public interface EmployeeService {
	public boolean addEmployee();
	public List<Employee> ShowAllData();
	public boolean DeleteData(int mobileid);
	
}
