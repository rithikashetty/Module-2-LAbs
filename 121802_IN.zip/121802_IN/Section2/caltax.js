var myWindow;
function salSlip()
{
	alert('Hello');
	
	var tit = document.salinfo.title.value;
	var fname= document.salinfo.firstname.value;
	var lstname= document.salinfo.lastname.value;
	var grsssal= document.salinfo.grosssal.value;
	var add= document.salinfo.address.value;
	var incometax;
	var netsalary;
	
	
		if((fname==null || fname=="")&&(lstname==null || lstname=="")&&(grsssal==null || grsssal=="")&&(add==null || add==""))
	{
		alert('Enter the details');
	}
	
	
	 myWindow = window.open("", "MsgWindow", "width=500,height=500");
	 
	  myWindow.document.write("<p align=center>Salary Slip</p>");
	  
	  myWindow.document.write("<table border=1 align= center><<tr><td> title</td> <td>firstname</td> <td>lastname</td> <td>Gross salary</td> <td>address</td> </tr>");
	  

	  if(fname==null || fname=="")&&(lstname==null || lstname=="")&&(grsssal==null || grsssal=="")&&(add==null || add=="")){
		  
			myWindow.document.write("<tr><td>tit</td><td>"+fname+" </td> <td>"+lstname +"</td> <td>"+grsssal+"</td> <td>"+add+"</td> </tr>");
			myWindow.document.write("</table>")
			
			if(grsssal<180000)
			{
				myWindow = window.write("<table> <tr><td>below 180000</td><td>nill</td></tr></table>");
				myWindow = window.write("Income tax is nill.No Income Tax");
			}
		  else if(grsssal=180000 && grsssal<=300000)
		  {
			  
			  myWindow = window.write(" <table><tr><td>180000 to 300000</td><td>10%</td></tr></table>");
			  netsalary = grsssal-0.1;                                                                     //calculating netsalary
			  myWindow = window.write("Net Salary of"+fname+" "+lstname+"is"+netsalary);
		  }
		  else if((grsssal=300001) && (grsssal<500000))
		  {
			   myWindow = window.write(" <table><tr><td>300001 to 500000</td><td>20%</td></tr></table>");
			   netsalary = grsssal-0.2;
			  myWindow = window.write("Net Salary of"+fname+" "+lstname+"is"+netsalary);
		  }
		  else if((grsssal>500000))
		  {
			   myWindow = window.write(" <table><tr><td>Above 500000</td><td>30%</td></tr></table>");
			   netsalary = grsssal-0.3;
			  myWindow = window.write("Net Salary of"+fname+" "+lstname+"is"+netsalary);
		  }
	  }
}