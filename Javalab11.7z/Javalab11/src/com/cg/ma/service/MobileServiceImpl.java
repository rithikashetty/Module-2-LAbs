package com.cg.ma.service;

import java.util.List;

import com.cg.ma.dao.IMobileDao;
import com.cg.ma.dao.MobileDaoImpl;
import com.cg.ma.dto.Mobile;
import com.cg.ma.exception.MobileException;


public class MobileServiceImpl implements IMobileService {
	
	IMobileDao imobile = new MobileDaoImpl();

	/*public List<Mobile> showAllMobiles() throws MobileException {
		
		return imobile.showAll();

	@Override
	public boolean deleteMobile(int mobileid) throws MobileException {
	
		return imobile.deleteMobile(mobileid);
	}

	public List<Mobile> searchByRange(int start, int end)
			throws MobileException {
		return imobile.searchByRange(start, end);
	}
	}
*/
	public List<Mobile> showAllMobiles() throws MobileException {
	
		return imobile.showAll();
	}

	public boolean deleteMobile(int mobileid) throws MobileException {

		return imobile.deleteMobile(mobileid);
		
	}

	public List<Mobile> searchByRange(int start, int end)
			throws MobileException {
		
		return imobile.searchByRange(start, end);
	}


	@Override
	public boolean Mobileid(int mid) throws MobileException {

		return imobile.Mobileid(mid);
		
	}

	@Override
	public boolean updateQty(int mid, int qty) throws MobileException {

		return imobile.updateQty(mid, qty);
		
	}

	@Override
	public List<Mobile> showAll() throws MobileException {
		// TODO Auto-generated method stub
		return null;
	}

}
