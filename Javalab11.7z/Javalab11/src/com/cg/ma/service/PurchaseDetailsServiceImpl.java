package com.cg.ma.service;

import com.cg.ma.dao.IPurchaseDetailsDao;
import com.cg.ma.dao.PurchaseDetailsDaoImpl;
import com.cg.ma.exception.PurchaseDetailsException;

public class PurchaseDetailsServiceImpl implements IPurchaseDetailsService {
	
	IPurchaseDetailsDao ipurchase = new PurchaseDetailsDaoImpl();
	
/*
	@Override
	public boolean insertPurchaseDetails(String cust_name, String cust_mail,
			String cust_phone, int mobileid)throws PurchaseDetailsException {
		
		return ipurchase.insertPurchaseDetails(cust_name, cust_mail, cust_phone, mobileid);
	}*/

	@Override
	public boolean insertPurchaseDetails(String cust_name, String cust_mail,
			String cust_phone, int mobileid) throws PurchaseDetailsException {
		// TODO Auto-generated method stub
		return ipurchase.insertPurchaseDetails(cust_name, cust_mail, cust_phone, mobileid);
	}

	
	
}
