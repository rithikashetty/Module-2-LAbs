package com.cg.ma.JunitTest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.ma.dao.IPurchaseDetailsDao;
import com.cg.ma.dao.PurchaseDetailsDaoImpl;
import com.cg.ma.exception.PurchaseDetailsException;

public class TestPurchaseDetailsDaoImpl {
	
	IPurchaseDetailsDao ipurchase;

	@Before
	public void setUp() throws Exception {
		
		ipurchase=new PurchaseDetailsDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		
		
	}

	@Test
	public void testInsertPurchaseDetails() {
		try{
			
			assertEquals(true,ipurchase.insertPurchaseDetails("Rithika", "rithikad@gmail.com", "9768130369",1001));
		}catch(PurchaseDetailsException e){
			
			e.printStackTrace();
		}

}
}
