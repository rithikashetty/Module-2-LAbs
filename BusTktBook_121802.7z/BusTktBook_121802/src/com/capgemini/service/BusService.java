package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.BusBean;
import com.capgemini.exception.BusException;

public interface BusService {
	
	List<BusBean> showAll();
	
	List<BusBean> showAllBusDetails();

	boolean BusId(int buid) throws BusException;//throws busExcetion

	boolean updateSeats(int buid, int noseat);

}
