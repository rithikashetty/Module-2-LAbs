package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.BusBean;
import com.capgemini.dao.BusDao;
import com.capgemini.dao.BusDaoImpl;
import com.capgemini.exception.BusException;

public class BusServiceImpl implements BusService {
	
	BusDao busDao= new BusDaoImpl();

	@Override
	public List<BusBean> showAllBusDetails() {

		return busDao.showAll();
		
	}

	@Override
	public List<BusBean> showAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean BusId(int buid) throws BusException {//throw busException
		
		return busDao.BusId(buid);
		
	}

	@Override
	public boolean updateSeats(int buid, int noseat) {
		// TODO Auto-generated method stub
		return busDao.updateSeats(buid,noseat);
	}

}
