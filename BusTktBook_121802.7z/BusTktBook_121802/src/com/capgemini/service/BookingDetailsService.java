package com.capgemini.service;

import com.capgemini.exception.BookingException;

public interface BookingDetailsService {


	boolean insertBookingDetails(String cid, int buid, int noseat) throws BookingException;

}

