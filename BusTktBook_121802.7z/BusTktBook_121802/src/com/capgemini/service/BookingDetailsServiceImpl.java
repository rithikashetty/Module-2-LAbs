package com.capgemini.service;

import com.capgemini.dao.BookingDetailsDao;
import com.capgemini.dao.BookingDetailsDaoImpl;
import com.capgemini.exception.BookingException;

public class BookingDetailsServiceImpl implements BookingDetailsService {

	BookingDetailsDao bookDao = new BookingDetailsDaoImpl();
	
	public boolean insertBookingDetails(String cid, int buid, int noseat) throws BookingException {//throw
		// TODO Auto-generated method stub
		return bookDao.insertBookingDetails(cid , buid ,noseat);
	}

}
