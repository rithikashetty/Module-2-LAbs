package com.capgemini.exception;

public class BusException extends Exception{

	public BusException(String msg){
		
		super(msg);
	}
	
	
}
