package com.capgemini.bean;

import java.sql.Date;
import java.time.LocalDate;

public class BusBean {

	private int busid;
	private String busType;
	private Date dateOfJourney;
	private String fromStop,toStop;
	private int availableSeats;
	private double fare;
	public BusBean() {
		super();
	}
	public BusBean(int busid, String busType, Date dateOfJourney,
			String fromStop, String toStop, int availableSeats, int fare) {
		super();
		this.busid = busid;
		this.busType = busType;
		this.dateOfJourney = dateOfJourney;
		this.fromStop = fromStop;
		this.toStop = toStop;
		this.availableSeats = availableSeats;
		this.fare = fare;
	}
	public int getBusid() {
		return busid;
	}
	public void setBusid(int busid) {
		this.busid = busid;
	}
	public String getBusType() {
		return busType;
	}
	public void setBusType(String busType) {
		this.busType = busType;
	}
	public Date getDateOfJourney() {
		return dateOfJourney;
	}
	public void setDateOfJourney(Date dateofjourney2) {
		this.dateOfJourney = dateofjourney2;
	}
	public String getFromStop() {
		return fromStop;
	}
	public void setFromStop(String fromStop) {
		this.fromStop = fromStop;
	}
	public String getToStop() {
		return toStop;
	}
	public void setToStop(String toStop) {
		this.toStop = toStop;
	}
	public int getAvailableSeats() {
		return availableSeats;
	}
	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}
	public double getFare() {
		return fare;
	}
	public void setFare(double fare2) {
		this.fare = fare2;
	}
	@Override
	public String toString() {
		return "BusBean [busid=" + busid + ", busType=" + busType
				+ ", dateOfJourney=" + dateOfJourney + ", fromStop=" + fromStop
				+ ", toStop=" + toStop + ", availableSeats=" + availableSeats
				+ ", fare=" + fare + "]";
	}
	
	
}
