package com.capgemini.bean;

public class BookingBean {
	
	private int bookingid;
	private int noOfSeat;
	private int busId;
	private String custId;
	public BookingBean() {
		super();
	}
	public BookingBean(int bookingid, int noOfSeat, int busId, String custId) {
		super();
		this.bookingid = bookingid;
		this.noOfSeat = noOfSeat;
		this.busId = busId;
		this.custId = custId;
	}
	public int getBookingid() {
		return bookingid;
	}
	public void setBookingid(int bookingid) {
		this.bookingid = bookingid;
	}
	public int getNoOfSeat() {
		return noOfSeat;
	}
	public void setNoOfSeat(int noOfSeat) {
		this.noOfSeat = noOfSeat;
	}
	public int getBusId() {
		return busId;
	}
	public void setBusId(int busId) {
		this.busId = busId;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	@Override
	public String toString() {
		return "BookingBean [bookingid=" + bookingid + ", noOfSeat=" + noOfSeat
				+ ", busId=" + busId + ", custId=" + custId + "]";
	}
	

}
