package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.bean.BookingBean;
import com.capgemini.exception.BookingException;
import com.capgemini.util.JdbcUtil;

public class BookingDetailsDaoImpl implements BookingDetailsDao {

	Connection conn;
	PreparedStatement pst;
	private static final Logger mylogger=Logger.getLogger(JdbcUtil.class);
	
	@Override
	public boolean insertBookingDetails(String cid, int buid, int noseat) throws BookingException {
		
		conn=JdbcUtil.getConnection();
		
		
		int qty=0;
		int rec =0;
		int qty1=0;
		
		String iquery="INSERT INTO BookingDetails VALUES(Booking_Id_Seq.NEXTVAL,?,?,?)";
		String squery="SELECT availableSeats FROM BusDetails WHERE busId=?";
		String squery1="SELECT BOOKINGID FROM BookingDetails WHERE CUSTID=?";
		try {
			pst=conn.prepareStatement(squery);
			pst.setInt(1,buid);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				
				qty=rs.getInt(1);
				System.out.println("Thank you.Your booking");
				mylogger.info("All Data is displayed");
			}
			
			

			
			if(qty>0){
				pst=conn.prepareStatement(iquery);
				pst.setString(1, cid);
				pst.setInt(2, buid);
				pst.setInt(3, noseat);
			
			BookingBean bb = new BookingBean();
			bb.setCustId(cid);
			bb.setBusId(buid);
			bb.setNoOfSeat(noseat);
			
			rec=pst.executeUpdate();
			if(rec>0){
				pst=conn.prepareStatement(squery1);
				pst.setString(1,cid);
				ResultSet rs1 =pst.executeQuery();
				while(rs1.next()){
					 qty1=rs1.getInt(1);//returns the value of quantity column and stores in qty1
					 System.out.println(qty1);
				return true;
				
			}
			
			}
			}	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BookingException("Data Not Inserted");
		}
		
		
		
		
		
		return false;
	}

}
