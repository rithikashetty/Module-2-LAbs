package com.capgemini.dao;

import com.capgemini.exception.BookingException;

public interface BookingDetailsDao {

	boolean insertBookingDetails(String cid, int buid, int noseat) throws BookingException;

}
