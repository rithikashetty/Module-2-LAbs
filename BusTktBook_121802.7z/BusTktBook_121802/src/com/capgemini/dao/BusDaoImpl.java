package com.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.bean.BusBean;
import com.capgemini.exception.BusException;
import com.capgemini.util.JdbcUtil;

public class BusDaoImpl implements BusDao {
	
	Connection conn;
	PreparedStatement pst;
	private static final Logger mylogger=Logger.getLogger(JdbcUtil.class);

	@Override
	public List<BusBean> showAll() {
		
		conn=JdbcUtil.getConnection();
		
		String query="SELECT * FROM BusDetails";
		
		List<BusBean>mList=new ArrayList<BusBean>();
		
		try {
			pst = conn.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				
				int busid = rs.getInt(1);
				String busType =rs.getString(2);
				String fromStop = rs.getString(3);
				String toStop=rs.getString(4);
				double fare=rs.getDouble(5);
				int availableseats = rs.getInt(6);
				Date dateofjourney = rs.getDate(7);
				
				BusBean b = new BusBean();
				b.setBusid(busid);
				b.setBusType(busType);
				b.setFromStop(fromStop);
				b.setToStop(toStop);
				b.setFare(fare);
				b.setAvailableSeats(availableseats);
				b.setDateOfJourney(dateofjourney);
				
				mList.add(b);
				
				mylogger.info("All Data is displayed");
				
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
finally{
			
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
	}
		return mList;
	}

	@Override
	public boolean BusId(int buid) throws BusException {
		conn=JdbcUtil.getConnection();
		int id=0;
		String query = "SELECT COUNT(busId) FROM BusDetails WHERE busId=?";
		try {
			pst=conn.prepareStatement(query);
			pst.setInt(1, buid);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				
				id=rs.getInt(1);
			}
			if(id==1){
				
				return true;
			}
			
			else{
				
				throw new BusException("Bus Id does not exist");
			}
			
		} catch (SQLException e) {
			System.out.println(e);
			e.printStackTrace();
		}
		
		
		return false;
	}

	@Override
	public boolean updateSeats(int buid, int noseat) {
		conn=JdbcUtil.getConnection();
		int rec=0;
		int noseat1=0;
		String sQuery = "SELECT availableseats FROM BusDetails WHERE busid=?";
		try {
			pst=conn.prepareStatement(sQuery);
			pst.setInt(1, buid);
			ResultSet rs = pst.executeQuery();//select query is executed
			while(rs.next()){
				
				
				noseat1=rs.getInt(1);//
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		return false;
	}
}
	
