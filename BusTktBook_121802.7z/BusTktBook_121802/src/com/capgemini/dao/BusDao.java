package com.capgemini.dao;

import java.util.List;

import com.capgemini.bean.BusBean;
import com.capgemini.exception.BusException;

public interface BusDao {

	List<BusBean> showAll();

	boolean BusId(int buid) throws BusException;//throw bus Exception

	boolean updateSeats(int buid, int noseat);
	
}
