package com.capgemini.client;

import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;
import com.capgemini.exception.BusException;
import com.capgemini.service.BookingDetailsService;
import com.capgemini.service.BookingDetailsServiceImpl;
import com.capgemini.service.BusService;
import com.capgemini.service.BusServiceImpl;
import com.capgemini.util.JdbcUtil;


public class MainClient {
	
	private static final Logger mylogger=Logger.getLogger(JdbcUtil.class);
	
	public static void main(String[] args) throws BusException, BookingException{
		
		PropertyConfigurator.configure("log4j.properties");
		mylogger.info("Application Started");
		System.out.println("Start");
		
		
		BusService busService = new BusServiceImpl();
		BookingDetailsService bDetailService = new BookingDetailsServiceImpl();
		
		int choice=0;
		
		do{
			printDetails();
			Scanner sc = new Scanner(System.in);
			choice =sc.nextInt();
			switch(choice){
			
/*				case 1:
					
					List<BusBean> mList = busService.showAllBusDetails();
					for(BusBean b:mList){
						
						System.out.println("BusId"+b.getBusid()+"Bus Type:"+b.getBusType()+"From Stop:"+b.getFromStop()+"To Stop:"+b.getToStop()+"Fare:"+b.getFare()+"available Seats:"+b.getAvailableSeats()+"Date Of Journey:"+b.getDateOfJourney());
					}
					
					break;*/
					
				case 1:
					
					
					List<BusBean> mList = busService.showAllBusDetails();
					for(BusBean b:mList){
						
						System.out.println("BusId"+b.getBusid()+"Bus Type:"+b.getBusType()+"From Stop:"+b.getFromStop()+"To Stop:"+b.getToStop()+"Fare:"+b.getFare()+"available Seats:"+b.getAvailableSeats()+"Date Of Journey:"+b.getDateOfJourney());
					}
					
					boolean checkcustid=false;
					String regCid="[A-Z]{1}[0-9]{6}";
					
					
					System.out.println("Enter Customer Id:");
					String cid = sc.next();
					
					
					System.out.println("Please Enter BusId:");
					int buid = sc.nextInt();
					
					
					
					System.out.println("Enter number of Seats:");
					int noseat = sc.nextInt();
					
					checkcustid = Pattern.matches(regCid, cid);
					boolean buid1 = busService.BusId(buid);

					
					if((checkcustid==true)&&(buid1==true)){
						
						bDetailService.insertBookingDetails(cid, buid, noseat);
						System.out.println("Thank You for booking");
						busService.updateSeats(buid,1);
						
					}
					else{
						
						System.out.println("Bus Id:"+buid1+"Customerid:"+checkcustid);
						System.out.println("Enter Proper Details");
					}
			
					break;
				case 2:
					PropertyConfigurator.configure("log4j.properties");
					mylogger.info("Application ended");
					System.out.println("end");
					break;
					
				default:
					System.out.println("enter choice between 1 to 3");
				
					}
			

		}while(choice!=2);
			
}
	


private static void printDetails() {
		
		
		System.out.println("*********************");
		System.out.println("Enter Choice");
		System.out.println("1.Book Ticket");
		System.out.println("2.exit");
		
	}
}